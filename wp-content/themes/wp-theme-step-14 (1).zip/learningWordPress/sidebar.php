<!-- side-column -->
<div class="side-column">
	
	<?php if (is_active_sidebar('sidebar1')) : ?>
	
		<?php dynamic_sidebar('sidebar1'); ?>
	
	<?php endif; ?>
	
</div><!-- /side-column -->