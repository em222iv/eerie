<?php


// Load WordPress without the theme being printed.
define('WP_USE_THEMES', FALSE);
require_once __DIR__.'/vendor/wordpress/wp-blog-header.php';







