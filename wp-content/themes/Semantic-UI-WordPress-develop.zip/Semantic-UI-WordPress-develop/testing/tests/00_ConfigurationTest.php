<?php

/**
 * @requires PHP 5.4
 * @requires PHPUnit 4
 */
class ConfigurationTest extends \PHPUnit_Framework_TestCase {
	
	/**
	 * @test
	 */
	public function True() {
		$this->assertTrue(TRUE);
	}
}
