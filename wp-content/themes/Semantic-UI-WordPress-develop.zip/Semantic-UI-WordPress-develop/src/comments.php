<?php
/**
 * Fetch the comments area
 */

theme::part('comments', 'content');
