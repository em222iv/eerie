<?php
/**
 * The footer. Always use the_footer() to make sure WordPress hooks are
 * always correctly called.
 */

theme::part('footer', 'content');
