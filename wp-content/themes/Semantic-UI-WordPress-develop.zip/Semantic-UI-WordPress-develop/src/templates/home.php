<?php
/*
Template Name: Home With Posts
*/

theme::part('layout', 'layout', 'sidebar-right');
