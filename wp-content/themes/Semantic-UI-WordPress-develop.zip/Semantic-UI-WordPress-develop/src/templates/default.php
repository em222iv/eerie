<?php
/*
Template Name: Default
*/

theme::part('layout', 'layout', 'sidebar-right');
