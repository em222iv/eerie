<?php
/*
Template Name: First-Run
*/

theme::use_part('header', 'content', 'header', 'none');
theme::use_part('footer', 'content', 'footer', 'none');
theme::use_part('modals', 'content', 'empty');
theme::part('layout', 'layout', 'first-run');
