<?php
/*
Template Name: Dev Notes
*/

theme::part('notes', 'include', 'dev-notes');
theme::part('layout', 'layout', 'dev-notes');
