<div id="theme-options-page" class="ui basic segment" style="max-width:99%;">
	<h1 class="ui huge header">
		Theme Options
	</h1>
	
	<?php theme::part('content', 'content', 'theme-options'); ?>
</div>
