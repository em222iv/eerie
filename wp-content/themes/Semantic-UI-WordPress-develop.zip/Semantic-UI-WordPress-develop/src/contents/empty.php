<?php
/**
 * This "empty" file is very important because it allows you to dynamically
 * exclude any part of the theme that is included via theme::part() (given the
 * part has not already been sent to PHP's buffer). The idea is to repurpose
 * parts instead of just deleting them.
 */
