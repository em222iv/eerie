<?php
/**
 * The default footer.
 */
?>
				</div>
			</div>
		</div>
	</div>
	
	<!-- Modals -->
	<?php theme::part('modals', 'content', 'modals'); ?>
	<!-- /Modals -->
	
	
	<?php wp_footer(); ?>
</body>
</html>
