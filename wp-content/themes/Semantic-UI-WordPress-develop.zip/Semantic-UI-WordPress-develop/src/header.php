<?php
/**
 * The header. Always use the_header() to make sure WordPress hooks are
 * always correctly called.
 */

theme::part('header', 'content');
